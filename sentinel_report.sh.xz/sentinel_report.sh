#!/usr/bin/env bash
set -euo pipefail

TS="$(date +%F_%H%M%S)"
HOST="${HOSTNAME:-$(hostname)}"
OUT_HTML="/tmp/sentinel_report_${HOST}_${TS}.html"
OUT_LOG="/tmp/sentinel_report_${HOST}_${TS}.log"

WATCH_PROCS_REGEX='(ss-server|shadowsocks|hbbs|hbbr|rustdesk|ngrok|frpc|frps|chisel|socat|nc|ncat|xmrig|cryptominer)'
WATCH_PORTS_REGEX='(:5588|:21118|:21119|:1080|:10808|:10809|:3333|:4444|:5555|:6666|:7777|:8888|:9999)'

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
  echo "ERROR: run as root. Example: sudo $0"
  exit 1
fi

html_escape() {
  sed -e 's/&/\&amp;/g' \
      -e 's/</\&lt;/g' \
      -e 's/>/\&gt;/g' \
      -e 's/"/\&quot;/g' \
      -e "s/'/\&#39;/g"
}

cmd() { { "$@" 2>&1 | tee -a "$OUT_LOG" ; } || true; }

slug() { echo "$*" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9]+/-/g; s/^-+|-+$//g'; }

command_bar() {
  local c="$*"
  local esc; esc="$(printf "%s" "$c" | html_escape)"
  cat <<EOF
<div class="cmdbar">
  <div class="cmdlabel">Command</div>
  <code class="cmdtext wrap-anywhere">${esc}</code>
  <button class="copybtn" type="button" data-copy="${esc}" title="Copy command">Copy</button>
</div>
EOF
}

card_pre() {
  local title="$1"; shift
  local anchor; anchor="$(slug "$title")"
  local command_str="$*"
  local output; output="$(cmd "$@" | html_escape)"
  cat <<EOF
<section class="card" id="${anchor}">
  <div class="card-head"><h2>${title}</h2></div>
  $(command_bar ${command_str})
  <pre class="mono">${output}</pre>
  <div class="card-foot"><a class="toplink" href="#top">Back to top ↑</a></div>
</section>
EOF
}

card_html() {
  local title="$1"
  local anchor; anchor="$(slug "$title")"
  cat <<EOF
<section class="card" id="${anchor}">
  <div class="card-head"><h2>${title}</h2></div>
EOF
  cat
  cat <<'EOF'
  <div class="card-foot"><a class="toplink" href="#top">Back to top ↑</a></div>
</section>
EOF
}

table_established() {
  local raw
  raw="$(ss -H -tunap state established 2>/dev/null || true)"
  echo -e "\n### ss -H -tunap state established\n" >> "$OUT_LOG"
  echo "$raw" >> "$OUT_LOG"

  command_bar "ss -H -tunap state established"
  cat <<'EOF'
<div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th>Proto</th><th>Recv-Q</th><th>Send-Q</th><th>Local</th><th>Remote</th><th>Process</th><th>Flags</th>
      </tr>
    </thead>
    <tbody>
EOF

  if [[ -z "$raw" ]]; then
    echo '<tr><td colspan="7" class="muted">No established connections found (or ss output unavailable).</td></tr>'
  else
    while IFS= read -r line; do
      [[ -z "$line" ]] && continue
      proto="$(awk '{print $1}' <<<"$line")"
      recvq="$(awk '{print $2}' <<<"$line")"
      sendq="$(awk '{print $3}' <<<"$line")"
      localaddr="$(awk '{print $4}' <<<"$line")"
      remoteaddr="$(awk '{print $5}' <<<"$line")"
      proc="$(cut -d' ' -f6- <<<"$line")"

      flags=()
      rowclass=""
      [[ "$sendq" != "0" ]] && flags+=("nonzero-sendq") && rowclass="row-warn"
      [[ "$proc" =~ $WATCH_PROCS_REGEX ]] && flags+=("watched-process") && rowclass="row-bad"
      [[ "$localaddr" =~ $WATCH_PORTS_REGEX ]] && flags+=("watched-port") && rowclass="row-warn"
      [[ "$proc" =~ sshd ]] && [[ "$localaddr" != *":22" ]] && flags+=("sshd-nonstandard-port")

      flags_str="$(IFS=', '; echo "${flags[*]:-—}")"

      printf '<tr class="%s">' "$(printf "%s" "$rowclass" | html_escape)"
      printf '<td class="mono">%s</td>' "$(printf "%s" "$proto" | html_escape)"
      printf '<td class="mono">%s</td>' "$(printf "%s" "$recvq" | html_escape)"
      printf '<td class="mono">%s</td>' "$(printf "%s" "$sendq" | html_escape)"
      printf '<td class="mono wrap-anywhere">%s</td>' "$(printf "%s" "$localaddr" | html_escape)"
      printf '<td class="mono wrap-anywhere">%s</td>' "$(printf "%s" "$remoteaddr" | html_escape)"
      printf '<td class="mono wrap-anywhere">%s</td>' "$(printf "%s" "$proc" | html_escape)"
      printf '<td class="wrap-anywhere">%s</td>' "$(printf "%s" "$flags_str" | html_escape)"
      echo '</tr>'
    done <<< "$raw"
  fi

  cat <<'EOF'
    </tbody>
  </table>
</div>
<p class="hint">Tip: focus on unknown remote IPs, watched processes, and long-lived connections.</p>
EOF
}

table_listening() {
  local raw
  raw="$(ss -H -tulnp 2>/dev/null || true)"
  echo -e "\n### ss -H -tulnp\n" >> "$OUT_LOG"
  echo "$raw" >> "$OUT_LOG"

  command_bar "ss -H -tulnp"
  cat <<'EOF'
<div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th>Proto</th><th>State</th><th>Local</th><th>Process</th><th>Flags</th>
      </tr>
    </thead>
    <tbody>
EOF

  if [[ -z "$raw" ]]; then
    echo '<tr><td colspan="5" class="muted">No listening sockets found (or ss output unavailable).</td></tr>'
  else
    while IFS= read -r line; do
      [[ -z "$line" ]] && continue
      proto="$(awk '{print $1}' <<<"$line")"
      state="$(awk '{print $2}' <<<"$line")"
      localaddr="$(awk '{print $5}' <<<"$line")"
      proc="$(cut -d' ' -f7- <<<"$line")"

      flags=()
      rowclass=""
      [[ "$proc" =~ $WATCH_PROCS_REGEX ]] && flags+=("watched-process") && rowclass="row-bad"
      [[ "$localaddr" =~ $WATCH_PORTS_REGEX ]] && flags+=("watched-port") && rowclass="row-warn"
      [[ "$localaddr" == *"0.0.0.0:"* || "$localaddr" == *"[::]:"* ]] && flags+=("bind-all-interfaces")
      flags_str="$(IFS=', '; echo "${flags[*]:-—}")"

      printf '<tr class="%s">' "$(printf "%s" "$rowclass" | html_escape)"
      printf '<td class="mono">%s</td>' "$(printf "%s" "$proto" | html_escape)"
      printf '<td class="mono">%s</td>' "$(printf "%s" "$state" | html_escape)"
      printf '<td class="mono wrap-anywhere">%s</td>' "$(printf "%s" "$localaddr" | html_escape)"
      printf '<td class="mono wrap-anywhere">%s</td>' "$(printf "%s" "$proc" | html_escape)"
      printf '<td class="wrap-anywhere">%s</td>' "$(printf "%s" "$flags_str" | html_escape)"
      echo '</tr>'
    done <<< "$raw"
  fi

  cat <<'EOF'
    </tbody>
  </table>
</div>
<p class="hint">Tip: unexpected listeners bound on 0.0.0.0/[::] are often the fastest wins to investigate.</p>
EOF
}

extract_candidate_pids() {
  local p1 p2
  p1="$(ss -H -tunap 2>/dev/null | sed -n 's/.*pid=\([0-9]\+\).*/\1/p' | sort -u || true)"
  p2="$(bash -lc "ps auxww | egrep -i '$WATCH_PROCS_REGEX' | egrep -v 'egrep|grep' || true" 2>/dev/null | awk '{print $2}' | sort -u || true)"
  printf "%s\n%s\n" "$p1" "$p2" | awk 'NF' | sort -u
}

card_pid_details() {
  local title="Candidate Process Details"
  local anchor; anchor="$(slug "$title")"
  local pids; pids="$(extract_candidate_pids | tr '\n' ' ' | sed 's/[[:space:]]\+/ /g; s/^ //; s/ $//')"

  echo -e "\n### Candidate PIDs\n$pids\n" >> "$OUT_LOG"

  cat <<EOF
<section class="card" id="${anchor}">
  <div class="card-head"><h2>${title}</h2></div>
  $(command_bar "ps -fp PID ; readlink -f /proc/PID/exe ; tr '\\0' ' ' < /proc/PID/cmdline ; readlink -f /proc/PID/cwd ; stat -c '%U' /proc/PID")
EOF

  if [[ -z "${pids:-}" ]]; then
    echo '<p class="muted">No candidate PIDs found.</p><div class="card-foot"><a class="toplink" href="#top">Back to top ↑</a></div></section>'
    return
  fi

  for pid in $pids; do
    [[ -d "/proc/$pid" ]] || continue
    psline="$(ps -fp "$pid" 2>&1 || true)"
    exe="$(readlink -f "/proc/$pid/exe" 2>/dev/null || true)"
    cmdline="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
    cwd="$(readlink -f "/proc/$pid/cwd" 2>/dev/null || true)"
    owner="$(stat -c '%U' "/proc/$pid" 2>/dev/null || true)"

    flags=()
    [[ "$cmdline" =~ $WATCH_PROCS_REGEX || "$exe" =~ $WATCH_PROCS_REGEX ]] && flags+=("watched-process")
    [[ "$exe" =~ ^/tmp|^/var/tmp|^/dev/shm ]] && flags+=("exec-from-temp")
    [[ "$owner" == "root" ]] && flags+=("running-as-root")
    flags_str="$(IFS=', '; echo "${flags[*]:-—}")"

    badge="info"
    [[ " ${flags[*]} " =~ " watched-process " || " ${flags[*]} " =~ " exec-from-temp " ]] && badge="bad"
    [[ "$badge" != "bad" && "${#flags[@]}" -gt 0 ]] && badge="warn"

    cat <<EOF
  <details class="details ${badge}">
    <summary>
      <span class="pid">PID ${pid}</span>
      <span class="pill ${badge}">${badge^^}</span>
      <span class="mono wrap-anywhere">User: ${owner:-?}</span>
      <span class="mono wrap-anywhere">Exe: ${exe:-?}</span>
      <span class="flags wrap-anywhere">Flags: ${flags_str}</span>
    </summary>
    <div class="details-body">
      <div class="grid">
        <div class="grid-item">
          <h4>ps</h4>
          $(command_bar "ps -fp ${pid}")
          <pre class="mono">$(printf "%s" "$psline" | html_escape)</pre>
        </div>
        <div class="grid-item">
          <h4>cmdline</h4>
          $(command_bar "tr '\\0' ' ' < /proc/${pid}/cmdline")
          <pre class="mono">$(printf "%s" "$cmdline" | html_escape)</pre>
        </div>
        <div class="grid-item">
          <h4>cwd</h4>
          $(command_bar "readlink -f /proc/${pid}/cwd")
          <pre class="mono">$(printf "%s" "$cwd" | html_escape)</pre>
        </div>
        <div class="grid-item">
          <h4>exe</h4>
          $(command_bar "readlink -f /proc/${pid}/exe")
          <pre class="mono">$(printf "%s" "$exe" | html_escape)</pre>
        </div>
      </div>
    </div>
  </details>
EOF
  done

  cat <<'EOF'
  <div class="card-foot"><a class="toplink" href="#top">Back to top ↑</a></div>
</section>
EOF
}

echo "Sentinel Report (raw log)" > "$OUT_LOG"
echo "Host: $HOST  Generated: $(date -Is)" >> "$OUT_LOG"
echo "HTML: $OUT_HTML" >> "$OUT_LOG"
echo "-----" >> "$OUT_LOG"

ESTAB_COUNT="$(ss -H -tunap state established 2>/dev/null | wc -l | tr -d ' ' || true)"
LISTEN_COUNT="$(ss -H -tulnp 2>/dev/null | wc -l | tr -d ' ' || true)"
WATCH_PS_COUNT="$(bash -lc "ps auxww | egrep -i '$WATCH_PROCS_REGEX' | egrep -v 'egrep|grep' || true" | wc -l | tr -d ' ' || true)"
WATCH_LISTEN_COUNT="$(ss -H -tulnp 2>/dev/null | egrep -i "$WATCH_PROCS_REGEX|$WATCH_PORTS_REGEX" | wc -l | tr -d ' ' || true)"

cat > "$OUT_HTML" <<EOF
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Sentinel Report - ${HOST} - ${TS}</title>
<style>
  :root{--bg:#0b1020;--text:#e6e9f2;--muted:#aab2d5;--info:#60a5fa;--warn:#fbbf24;--bad:#fb7185;--line:#223058;
        --mono:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;
        --sans:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,"Noto Sans",Arial;}
  html,body{background:radial-gradient(1200px 800px at 20% 0%, #121a3a 0%, var(--bg) 40%), var(--bg);color:var(--text);margin:0;font-family:var(--sans);}
  a{color:var(--info);text-decoration:none} a:hover{text-decoration:underline}
  .mono{font-family:var(--mono);}
  .wrap{max-width:1280px;margin:0 auto;padding:22px;}
  header{display:flex;gap:16px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;}
  h1{margin:0;font-size:22px;letter-spacing:.2px;}
  .sub{color:var(--muted);font-size:13px;line-height:1.4;max-width:100%;}
  .chips{display:flex;gap:8px;flex-wrap:wrap;}
  .chip{background:rgba(96,165,250,.12);border:1px solid rgba(96,165,250,.25);color:var(--text);padding:6px 10px;border-radius:999px;font-size:12px;white-space:normal;line-height:1.25;max-width:100%;}
  .chip.warn{background:rgba(251,191,36,.12);border-color:rgba(251,191,36,.25)}
  .chip.bad{background:rgba(251,113,133,.12);border-color:rgba(251,113,133,.25)}
  .sub,.meta,.chip,.badge,.kpi .small,.kpi .big,td,th,.mono,summary,.flags,.cmdline,code{overflow-wrap:anywhere;word-break:break-word;}
  .wrap-anywhere{overflow-wrap:anywhere;word-break:break-word;}
  .layout{display:grid;grid-template-columns:280px 1fr;gap:14px;margin-top:14px;}
  @media (max-width:980px){.layout{grid-template-columns:1fr;} .sidebar{position:relative;}}
  .sidebar{position:sticky;top:14px;align-self:start;border:1px solid var(--line);border-radius:16px;background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.01));padding:12px;max-height:calc(100vh - 28px);overflow:auto;}
  .sidebar h3{margin:0 0 10px;font-size:13px;color:#dbe2ff;}
  .nav a{display:block;padding:8px 10px;border-radius:12px;margin:4px 0;border:1px solid rgba(255,255,255,.06);background:rgba(0,0,0,.12);}
  .nav a:hover{background:rgba(255,255,255,.04)}
  .nav .small{font-size:11px;color:var(--muted);margin-top:2px}
  .main{min-width:0;}
  .kpi{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px;}
  .kpi .box{flex:1;min-width:220px;padding:12px;border-radius:14px;border:1px solid var(--line);background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.01));}
  .kpi .box h3{margin:0 0 6px;font-size:13px;}
  .kpi .box .big{font-size:22px;font-weight:800;letter-spacing:.3px;line-height:1.1;}
  .kpi .box .small{color:var(--muted);font-size:12px;}
  .card{border:1px solid var(--line);border-radius:16px;background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.01));padding:14px 14px 10px;box-shadow:0 10px 30px rgba(0,0,0,.25);margin-top:14px;overflow:hidden;}
  .card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;flex-wrap:wrap;min-width:0;}
  .card h2{margin:0;font-size:16px;}
  .meta{color:var(--muted);font-size:12px;min-width:0;}
  .card-foot{margin-top:10px;display:flex;justify-content:flex-end;}
  .toplink{font-size:12px;color:var(--muted);}
  .cmdbar{display:flex;align-items:center;gap:10px;margin-top:10px;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.18);min-width:0;}
  .cmdlabel{font-size:11px;letter-spacing:.4px;text-transform:uppercase;color:var(--muted);flex:0 0 auto;}
  .cmdtext{font-family:var(--mono);font-size:12px;padding:6px 8px;border-radius:10px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);flex:1 1 auto;min-width:0;}
  .copybtn{flex:0 0 auto;border-radius:10px;padding:7px 10px;cursor:pointer;font-size:12px;border:1px solid rgba(255,255,255,.10);background:rgba(96,165,250,.12);color:var(--text);}
  .copybtn:hover{background:rgba(96,165,250,.18)} .copybtn:active{transform:translateY(1px)}
  .toast{position:fixed;right:16px;bottom:16px;background:rgba(0,0,0,.70);border:1px solid rgba(255,255,255,.12);padding:10px 12px;border-radius:12px;color:var(--text);font-size:12px;opacity:0;transform:translateY(8px);transition:opacity .15s ease, transform .15s ease;pointer-events:none;}
  .toast.show{opacity:1;transform:translateY(0);}
  pre{margin:12px 0 0;padding:12px;background:rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.06);border-radius:12px;overflow:auto;max-height:520px;white-space:pre;overflow-x:auto;max-width:100%;}
  .table-wrap{overflow:auto;border-radius:12px;border:1px solid rgba(255,255,255,.06);margin-top:12px;max-width:100%;}
  table{width:100%;border-collapse:collapse;min-width:980px;background:rgba(0,0,0,.18);}
  th,td{padding:10px;border-bottom:1px solid rgba(255,255,255,.06);vertical-align:top;font-size:12px;}
  th{position:sticky;top:0;background:rgba(17,26,51,.95);text-align:left;color:#dbe2ff;}
  tr:hover td{background:rgba(255,255,255,.03)}
  .row-warn td{background:rgba(251,191,36,.06)}
  .row-bad td{background:rgba(251,113,133,.07)}
  .hint{color:var(--muted);font-size:12px;margin:10px 2px 4px;}
  .muted{color:var(--muted);}
  .details{border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:10px 12px;margin-top:10px;background:rgba(0,0,0,.12);overflow:hidden;}
  .details.info{border-color:rgba(96,165,250,.25)}
  .details.warn{border-color:rgba(251,191,36,.25)}
  .details.bad{border-color:rgba(251,113,133,.28)}
  summary{cursor:pointer;display:flex;gap:10px;align-items:center;flex-wrap:wrap;list-style:none;min-width:0;}
  summary::-webkit-details-marker{display:none;}
  .pid{font-weight:700}
  .pill{font-size:11px;padding:3px 8px;border-radius:999px;border:1px solid transparent}
  .pill.info{background:rgba(96,165,250,.12);border-color:rgba(96,165,250,.25)}
  .pill.warn{background:rgba(251,191,36,.12);border-color:rgba(251,191,36,.25)}
  .pill.bad{background:rgba(251,113,133,.12);border-color:rgba(251,113,133,.25)}
  .flags{flex-basis:100%;color:var(--muted);font-size:12px}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
  .grid-item{min-width:0;}
  @media (max-width:980px){.grid{grid-template-columns:1fr;} table{min-width:760px;}}
  h4{margin:10px 0 8px;font-size:12px;color:#dbe2ff}
  footer{margin:18px 0 0;color:var(--muted);font-size:12px;}
  ul{margin:10px 0 0 18px;}
</style>
</head>
<body>
<div class="wrap" id="top">
  <header>
    <div>
      <h1>Sentinel Report</h1>
      <div class="sub">
        Host: <span class="mono">${HOST}</span> · Generated: <span class="mono">$(date -Is)</span><br/>
        Output files: <span class="mono wrap-anywhere">${OUT_HTML}</span> (HTML), <span class="mono wrap-anywhere">${OUT_LOG}</span> (raw)
      </div>
    </div>
    <div class="chips">
      <div class="chip">Ubuntu report (read-only)</div>
      <div class="chip warn">Review watched processes</div>
      <div class="chip bad">Investigate unknown IPs</div>
    </div>
  </header>

  <div class="kpi">
    <div class="box">
      <h3>Established Connections</h3>
      <div class="big mono">${ESTAB_COUNT}</div>
      <div class="small">Uses: <span class="mono">ss -H -tunap state established</span></div>
    </div>
    <div class="box">
      <h3>Listening Sockets</h3>
      <div class="big mono">${LISTEN_COUNT}</div>
      <div class="small">Uses: <span class="mono">ss -H -tulnp</span></div>
    </div>
    <div class="box">
      <h3>Watched Processes</h3>
      <div class="big mono">${WATCH_PS_COUNT}</div>
      <div class="small">Uses: <span class="mono wrap-anywhere">bash -lc "ps auxww | egrep -i '${WATCH_PROCS_REGEX}' | egrep -v 'egrep|grep' || true"</span></div>
    </div>
    <div class="box">
      <h3>Watched Listeners</h3>
      <div class="big mono">${WATCH_LISTEN_COUNT}</div>
      <div class="small">Uses: <span class="mono wrap-anywhere">ss -H -tulnp | egrep -i '(WATCH_PROCS_REGEX|WATCH_PORTS_REGEX)'</span></div>
    </div>
  </div>

  <div class="layout">
    <aside class="sidebar">
      <h3>Jump to section</h3>
      <nav class="nav">
        <a href="#system-overview">System Overview<div class="small">Kernel, OS, IPs, routes</div></a>
        <a href="#established-connections-ss">Established Connections (ss)<div class="small">Active TCP/UDP sessions</div></a>
        <a href="#listening-sockets-ss">Listening Sockets (ss)<div class="small">Services exposed on ports</div></a>
        <a href="#watched-processes-ps-auxww-egrep-i-watch-regex">Watched Processes<div class="small">Quick regex match</div></a>
        <a href="#candidate-process-details">Candidate Process Details<div class="small">Deep dive per PID</div></a>
        <a href="#running-services-systemd">Running Services<div class="small">systemd status</div></a>
        <a href="#firewall-ufw">Firewall<div class="small">ufw/iptables/nft</div></a>
        <a href="#current-sessions-who">Users & Logins<div class="small">who/w/last/lastb</div></a>
        <a href="#cron-and-persistence">Cron & Persistence<div class="small">crontabs, /tmp, SUID</div></a>
        <a href="#logs">Logs<div class="small">journalctl ssh + keyword scan</div></a>
        <a href="#notes">Notes<div class="small">What to do next</div></a>
      </nav>
    </aside>

    <main class="main">
EOF

{
  cat <<'EOF'
<div class="grid" style="grid-template-columns:1fr; gap:14px;">
  <div class="muted">Quick baseline of OS, kernel, and network configuration.</div>
EOF
  printf "<h4>uname -a</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "uname -a")" "$(cmd uname -a | html_escape)"
  printf "<h4>lsb_release -a</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "lsb_release -a")" "$(cmd lsb_release -a | html_escape)"
  printf "<h4>uptime</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "uptime")" "$(cmd uptime | html_escape)"
  printf "<h4>ip -brief addr</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "ip -brief addr")" "$(cmd ip -brief addr | html_escape)"
  printf "<h4>ip route</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "ip route")" "$(cmd ip route | html_escape)"
  echo "</div>"
} | card_html "System Overview" >> "$OUT_HTML"

{ table_established; } | card_html "Established Connections (ss)" >> "$OUT_HTML"
{ table_listening; } | card_html "Listening Sockets (ss)" >> "$OUT_HTML"

card_pre "Watched Processes (ps auxww | egrep -i WATCH_REGEX)" bash -lc \
  "ps auxww | egrep -i '$WATCH_PROCS_REGEX' | egrep -v 'egrep|grep' || true" >> "$OUT_HTML"

card_pid_details >> "$OUT_HTML"

card_pre "Running Services (systemd)" systemctl --no-pager --type=service --state=running >> "$OUT_HTML"
card_pre "Interesting Unit Files (search)" bash -lc \
  "systemctl --no-pager list-unit-files | egrep -i 'shadowsocks|rustdesk|hbbs|hbbr|ngrok|frp|chisel|socat' || true" >> "$OUT_HTML"

card_pre "Firewall (ufw)" ufw status verbose >> "$OUT_HTML"
card_pre "iptables rules (iptables -S)" iptables -S >> "$OUT_HTML"
card_pre "nft ruleset (nft list ruleset)" nft list ruleset >> "$OUT_HTML"

card_pre "Current Sessions (who)" who >> "$OUT_HTML"
card_pre "Current Activity (w)" w >> "$OUT_HTML"
card_pre "Recent Logins (last -i, top 50)" bash -lc "last -i | head -n 50" >> "$OUT_HTML"
card_pre "Failed Logins (lastb -i, top 50)" bash -lc "lastb -i | head -n 50 || true" >> "$OUT_HTML"
card_pre "Effective sshd config (sshd -T, key items)" bash -lc \
  "sshd -T | egrep -i 'port|permitrootlogin|passwordauthentication|pubkeyauthentication|allowusers|allowgroups' || true" >> "$OUT_HTML"
card_pre "authorized_keys (first 200 lines each, limited search)" bash -lc \
  "find /home /root -maxdepth 3 -type f -name 'authorized_keys' -print -exec bash -lc 'echo \"---- {} ----\"; sed -n \"1,200p\" \"{}\"' \\; 2>/dev/null || true" >> "$OUT_HTML"

{
  cat <<'EOF'
<div class="muted">Common persistence spots: user/root crontabs, cron directories, temp executables, SUID binaries.</div>
EOF
  printf "<h4>Root crontab</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "crontab -l")" "$(cmd bash -lc "crontab -l || true" | html_escape)"
  printf "<h4>All user crontabs</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "for u in \$(cut -d: -f1 /etc/passwd); do crontab -u \$u -l; done")" "$(cmd bash -lc "for u in \$(cut -d: -f1 /etc/passwd); do echo \"\n# crontab -u \$u\"; crontab -u \$u -l 2>/dev/null || true; done" | html_escape)"
  printf "<h4>Cron directories</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "ls -la /etc/cron.d /etc/cron.daily /etc/cron.hourly /etc/cron.weekly /etc/cron.monthly")" "$(cmd ls -la /etc/cron.d /etc/cron.daily /etc/cron.hourly /etc/cron.weekly /etc/cron.monthly | html_escape)"
  printf "<h4>Recent files in /tmp /var/tmp /dev/shm (top 100)</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "find /tmp /var/tmp /dev/shm -maxdepth 2 -type f -printf '%TY-%Tm-%Td %TH:%TM:%TS %p\n' | sort -r | head -n 100")" "$(cmd bash -lc "find /tmp /var/tmp /dev/shm -maxdepth 2 -type f -printf '%TY-%Tm-%Td %TH:%TM:%TS %p\n' 2>/dev/null | sort -r | head -n 100 || true" | html_escape)"
  printf "<h4>SUID binaries (top 200, same filesystem)</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "find / -xdev -type f -perm -4000 -printf '%p\n' | sort | head -n 200")" "$(cmd bash -lc "find / -xdev -type f -perm -4000 -printf '%p\n' 2>/dev/null | sort | head -n 200 || true" | html_escape)"
} | card_html "Cron and Persistence" >> "$OUT_HTML"

{
  cat <<'EOF'
<div class="muted">SSH/auth logs and quick keyword scan. Tail limits keep the HTML readable.</div>
EOF
  printf "<h4>journalctl -u ssh (last 7 days, tail 500)</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "journalctl --no-pager -u ssh --since '7 days ago' | tail -n 500")" "$(cmd bash -lc "journalctl --no-pager -u ssh --since '7 days ago' | tail -n 500 || true" | html_escape)"
  printf "<h4>journalctl keyword scan (last 48 hours, tail 500)</h4>%s<pre class='mono'>%s</pre>\n" "$(command_bar "journalctl --no-pager --since '48 hours ago' | egrep -i 'sshd|failed password|accepted|invalid user|hbbs|hbbr|shadowsocks|ss-server|rustdesk|ngrok|frp|chisel' | tail -n 500")" "$(cmd bash -lc "journalctl --no-pager --since '48 hours ago' | egrep -i 'sshd|failed password|accepted|invalid user|hbbs|hbbr|shadowsocks|ss-server|rustdesk|ngrok|frp|chisel' | tail -n 500 || true" | html_escape)"
} | card_html "Logs" >> "$OUT_HTML"

cat >> "$OUT_HTML" <<'EOF'
<section class="card" id="notes">
  <div class="card-head"><h2>Notes</h2></div>
  <ul class="muted">
    <li>If you see <span class="mono">ss-server</span> (Shadowsocks) or <span class="mono">hbbs/hbbr</span> (RustDesk) and you did not install them, treat as potentially compromised.</li>
    <li>Be careful when sharing this HTML: it contains public IPs, usernames, paths, and service details.</li>
  </ul>
  <div class="card-foot"><a class="toplink" href="#top">Back to top ↑</a></div>
</section>

<footer>HTML: <span class="mono wrap-anywhere">__OUT_HTML__</span> · LOG: <span class="mono wrap-anywhere">__OUT_LOG__</span></footer>

<div id="toast" class="toast" aria-live="polite">Copied</div>

<script>
(function(){
  function showToast(msg){
    var t=document.getElementById('toast');
    if(!t) return;
    t.textContent=msg || 'Copied';
    t.classList.add('show');
    setTimeout(function(){ t.classList.remove('show'); }, 900);
  }
  async function copyText(text){
    try{ await navigator.clipboard.writeText(text); showToast('Command copied'); }
    catch(e){
      var ta=document.createElement('textarea');
      ta.value=text;
      document.body.appendChild(ta);
      ta.select();
      try{ document.execCommand('copy'); showToast('Command copied'); }
      catch(_){ showToast('Copy failed'); }
      document.body.removeChild(ta);
    }
  }
  document.addEventListener('click', function(e){
    var btn=e.target.closest('.copybtn');
    if(!btn) return;
    var text=btn.getAttribute('data-copy') || '';
    var decoded=text
      .replace(/&amp;/g,'&')
      .replace(/&lt;/g,'<')
      .replace(/&gt;/g,'>')
      .replace(/&quot;/g,'"')
      .replace(/&#39;/g,"'");
    copyText(decoded);
  });
})();
</script>
</body>
</html>
EOF

sed -i "s|__OUT_HTML__|$(printf "%s" "$OUT_HTML" | sed 's|/|\\/|g')|g; s|__OUT_LOG__|$(printf "%s" "$OUT_LOG" | sed 's|/|\\/|g')|g" "$OUT_HTML"

echo "HTML report saved to: $OUT_HTML"
echo "Raw log saved to:    $OUT_LOG"
echo "Open locally with:   xdg-open $OUT_HTML"
